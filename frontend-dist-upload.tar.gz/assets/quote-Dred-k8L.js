import{U as e}from"./index-BCyhPWUu.js";function r(t){return e.post("/api/developer/quotes",t)}function p(){return e.get("/api/developer/quotes/my")}export{r as c,p as f};
