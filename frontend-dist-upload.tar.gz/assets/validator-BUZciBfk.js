import{j as i}from"./index-BCyhPWUu.js";const n=o=>["",...i].includes(o);export{n as i};
